#include "guesser.h"

int main() {
  VerifyGuess();

  return 0;
}