#include <stdio.h>

#include "ultra_terminator.h"

int main() {
  // Start Ultra Terminator program
  RunUltraTerminator();

  return 0;
}