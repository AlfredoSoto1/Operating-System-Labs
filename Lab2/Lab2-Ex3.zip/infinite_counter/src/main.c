#include "inf_counter.h"

int main() {
  UpdateProgramCounter();
  return 0;
}