#ifndef GREETINGS_H
#define GREETINGS_H

/**
 * @brief Prints the greetings message and waits for 10 seconds
 *
 */
void PrintGreetings();

/**
 * @brief Prints the by message
 *
 */
void PrintByeMessage();

#endif  // GREETINGS_H