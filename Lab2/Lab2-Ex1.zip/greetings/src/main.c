#include "greetings.h"

int main() {
  PrintGreetings();
  PrintByeMessage();
  return 0;
}