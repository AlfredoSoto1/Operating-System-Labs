#include "Plotting.h"

int main() {
  RunTest();
  return 0;
}