#include "imu_driver.h"

int main() {
  LaunchImuDriver();
  return 0;
}