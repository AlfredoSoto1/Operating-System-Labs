#include "two_threads.h"

int main() {
  // Start two_threads program :)
  SpawnThreads();
  return 0;
}