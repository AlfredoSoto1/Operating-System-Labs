#include "ProgramThreads.h"

int main() {
  PrepareGame();
  return 0;
}