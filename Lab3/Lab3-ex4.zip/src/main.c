#include "ProgramThreads.h"

int main() {
  // Prepares and starts rendering the game
  PrepareRender();
  return 0;
}